To compile this program, please use the following line:

gcc -std=c99 -o smallsh smallsh.c
